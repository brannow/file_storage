local tinsert = table.insert

local inserted_schmaco = false

function DBMCPSchmaco()
	if inserted_schmaco then return end
	tinsert(DBM.Counts, {text = "Schmaco", value = "Schmaco", path = "Interface\\AddOns\\DBM-Counter-Schmaco\\Schmaco\\", max = 5})
	inserted_schmaco = true
end
